/**
 ****************************************************************************************
 *
 * @file boot.h
 *
 * @brief This file contains the declarations of the boot related variables.
 *
 * Copyright (C) RivieraWaves 2009-2013
 *
 * $Rev: 7039 $
 *
 ****************************************************************************************
 */

#ifndef _BOOT_H_
#define _BOOT_H_

#endif // _BOOT_H_
